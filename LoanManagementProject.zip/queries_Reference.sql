create table test.UserDetails (username varchar(20),password varchar(10) ,PRIMARY KEY (username));

create table test.LoanDetails(applno varchar(20),purpose varchar(20),amtrequest varchar(20),doa date,bstructure varchar(20),
bindicator varchar(20),address varchar(20),email varchar(20),mobile varchar(20),status varchar(20),
sancamt varchar(20), emi varchar(20), roi varchar(20), tol varchar(20),username varchar(20),FOREIGN KEY (username) REFERENCES UserDetails(username),tpa varchar(20),
 Primary key(applno));
 
 
 