package com.iiht.evaluation.eloan.dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import javax.activation.DataSource;
import javax.servlet.RequestDispatcher;

//import com.iiht.evaluation.eloan.controller.from;
//import com.iiht.evaluation.eloan.controller.where;
import com.iiht.evaluation.eloan.dto.LoanDto;
import com.iiht.evaluation.eloan.dto.LoanStatus;
import com.iiht.evaluation.eloan.model.ApprovedLoan;
import com.iiht.evaluation.eloan.model.LoanInfo;
import com.iiht.evaluation.eloan.model.User;
import com.iiht.evaluation.eloan.model.LoanInfo;



public class ConnectionDao {
	private static final long serialVersionUID = 1L;
	private String JDBdriver;
	private String jdbcURL;
	private String jdbcUsername;
	private String jdbcPassword;
	private Connection jdbcConnection;
	private DataSource dataSource;
	
	 public ConnectionDao(DataSource dataSource) {
	        this.dataSource = dataSource;
	    }

	public ConnectionDao(String JDBdriver,String jdbcURL, String jdbcUsername, String jdbcPassword) {
		this.JDBdriver=JDBdriver;
        this.jdbcURL = jdbcURL;
        this.jdbcUsername = jdbcUsername;
        this.jdbcPassword = jdbcPassword;
    }

	public  Connection connect() throws SQLException {
		if (jdbcConnection == null || jdbcConnection.isClosed()) {
			try {
				Class.forName("com.mysql.jdbc.Driver");
			} catch (ClassNotFoundException e) {
				throw new SQLException(e);
			}
			jdbcConnection = DriverManager.getConnection(jdbcURL, jdbcUsername, jdbcPassword);
			System.out.println("Connected");
		}
		return jdbcConnection;
	}

	public void disconnect() throws SQLException {
		if (jdbcConnection != null && !jdbcConnection.isClosed()) {
			jdbcConnection.close();
		}
	}
	
	// put the relevant DAO methods here..
	
	public int insertUser(User user) throws SQLException{
		try {
		this.connect();
		ResultSet result;
		int update_result;
		String fetch_user="Select * from UserDetails where username=?";
		PreparedStatement pstmt=jdbcConnection.prepareStatement(fetch_user);
		pstmt.setString(1, user.getUsername());
		result = pstmt.executeQuery();
		Boolean user_found=false;
		while(result.next())
				{
			user_found=true;
			break;
				}
		if(user_found)
		{
			return 0;
		}
		String insert_username="INSERT INTO UserDetails(username,password) VALUES(?,?)";
		pstmt=jdbcConnection.prepareStatement(insert_username);
		pstmt.setString(1,user.getUsername());
		pstmt.setString(2,user.getPassword());
		update_result = pstmt.executeUpdate();
		System.out.println("Dao...");
	} catch (SQLException e) {
		// TODO Auto-generated catch block
		System.out.println(e);
		e.printStackTrace();
	}
		catch(Exception ex) {
			System.out.println(ex);
			ex.printStackTrace();
		}finally {
			this.disconnect();
		}
		
	return 1;	
}
	public User getUser(User user) throws Exception{
		User fetchedUser = new User("", "");
		try {
		this.connect();
		ResultSet result1;
		PreparedStatement pstmt=jdbcConnection.prepareStatement("Select * from UserDetails where username=?");
		pstmt.setString(1, user.getUsername());
		result1=pstmt.executeQuery();
		while(result1.next())
		{
			String username=result1.getString(1);
			String password=result1.getString(2);
			fetchedUser.setUsername(username);
			fetchedUser.setPassword(password);
			//System.out.println(username + " " +password);
		}
		}catch (SQLException e) {
			// TODO Auto-generated catch block
			System.out.println(e);
			e.printStackTrace();
		}finally {
			this.disconnect();
		}
		//System.out.println(fetchedUser.getUsername() + " :: " + fetchedUser.getPassword());
		return fetchedUser;
	}
	
	public int getLoanApplNo() throws SQLException {
		ResultSet resultSet;
		int applNo = 1;
		String query = "Select count(*) from LoanDetails;";
		try {
			this.connect();
			PreparedStatement pstmt=jdbcConnection.prepareStatement(query);
			resultSet = pstmt.executeQuery();
			resultSet.next();
			applNo = resultSet.getInt(1) + 1;
			System.out.println("ApplNo: " + applNo);
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			System.out.println("From Catch -> ApplNo: " + applNo);
			e.printStackTrace();
		}
		finally {
			this.disconnect();
		}
		return applNo;
	}
	
	public int Loan_In_SQL(LoanInfo loaninfo) throws SQLException{
		int result=0;
		try {
		this.connect();
		
		String SQL_username="INSERT INTO LoanDetails(applno,purpose,amtrequest,doa,bstructure,bindicator,address,email,mobile,status) VALUES(?,?,?,?,?,?,?,?,?,?)";
		PreparedStatement pstmt=jdbcConnection.prepareStatement(SQL_username);
		pstmt.setString(1,loaninfo.getApplno());
		pstmt.setString(2,loaninfo.getPurpose());
		pstmt.setString(3,loaninfo.getAmtrequest());
		pstmt.setString(4,loaninfo.getDoa());
		pstmt.setString(5,loaninfo.getBstructure());
		pstmt.setString(6,loaninfo.getBindicator());
		pstmt.setString(7,loaninfo.getAddress());
		pstmt.setString(8,loaninfo.getEmail());
		pstmt.setString(9,loaninfo.getMobile());
		pstmt.setString(10,loaninfo.getStatus());
		result = pstmt.executeUpdate();
		System.out.println("Dao...");
	} catch (SQLException e) {
		// TODO Auto-generated catch block
		System.out.println(e);
		e.printStackTrace();
	}
		catch(Exception ex) {
			System.out.println(ex);
			ex.printStackTrace();
		}finally {
			this.disconnect();
		}
		
	return result;	
}
	
	public int updateLoanApp(LoanInfo loaninfo) throws SQLException{
		int result=0;
		try {
		this.connect();
		String query = "update loandetails set purpose=?,amtrequest=?,doa=?,bstructure=?,bindicator=?,address=?,email=?,mobile=?,status=? where applno=?";
		PreparedStatement pstmt=jdbcConnection.prepareStatement(query);
		pstmt.setString(10,loaninfo.getApplno());
		pstmt.setString(1,loaninfo.getPurpose());
		pstmt.setString(2,loaninfo.getAmtrequest());
		pstmt.setString(3,loaninfo.getDoa());
		pstmt.setString(4,loaninfo.getBstructure());
		pstmt.setString(5,loaninfo.getBindicator());
		pstmt.setString(6,loaninfo.getAddress());
		pstmt.setString(7,loaninfo.getEmail());
		pstmt.setString(8,loaninfo.getMobile());
		pstmt.setString(9,loaninfo.getStatus());
		result = pstmt.executeUpdate();
		System.out.println("Dao...");
	} catch (SQLException e) {
		// TODO Auto-generated catch block
		System.out.println(e);
		e.printStackTrace();
	}
		catch(Exception ex) {
			System.out.println(ex);
			ex.printStackTrace();
		}finally {
			this.disconnect();
		}
		
	return result;	
}	
	
	public List<LoanInfo> getLoansList() throws SQLException{
	 
		 List<LoanInfo> loaninfos = new ArrayList<LoanInfo>();
		 try {
				this.connect();
				ResultSet result1;
				PreparedStatement pstmt=jdbcConnection.prepareStatement("select * from LoanDetails where status != 'Approved'");
				//pstmt.setString(1,loaninfo.getApplno());
				result1=pstmt.executeQuery();
				while(result1.next())
				{try {
					LoanInfo loaninfo=new LoanInfo();
					loaninfo.setApplno(result1.getString(1));
					loaninfo.setPurpose(result1.getString(2));
					loaninfo.setAmtrequest(result1.getString(3));
					loaninfo.setDoa(result1.getString(4));
					loaninfo.setBstructure(result1.getString(5));
					loaninfo.setBindicator(result1.getString(6));
					loaninfo.setAddress(result1.getString(7));
					loaninfo.setEmail(result1.getString(8));
					loaninfo.setMobile(result1.getString(9));
					loaninfo.setStatus(result1.getString(10));
					loaninfos.add(loaninfo);
				}catch (SQLException e) {
					// TODO Auto-generated catch block
					System.out.println("An error occured, Could not retrive the loan status details!\"");
					e.printStackTrace();
				}
				}
		 }finally {
					this.disconnect();
				}
				return loaninfos;
	}
	
	public List<ApprovedLoan> getApprovedLoansList() throws SQLException{
		 
		 List<ApprovedLoan> loaninfos = new ArrayList<ApprovedLoan>();
		 try {
				this.connect();
				ResultSet result1;
				PreparedStatement pstmt=jdbcConnection.prepareStatement("select *  from LoanDetails where status='Approved'");
				//pstmt.setString(1,loaninfo.getApplno());
				result1=pstmt.executeQuery();
				while(result1.next())
				{try {
					ApprovedLoan apploaninfo=new ApprovedLoan();
					apploaninfo.setApplno(result1.getString(1));
					apploaninfo.setAmotsanctioned(Integer.valueOf(result1.getString(11)));
					apploaninfo.setEmi(Integer.valueOf(result1.getString(12)));
					apploaninfo.setLoanterm(Integer.valueOf(result1.getString(14)));
					loaninfos.add(apploaninfo);
				}catch (SQLException e) {
					// TODO Auto-generated catch block
					System.out.println("An error occured, Could not retrive the loan status details!\"");
					e.printStackTrace();
				}
				}
		 }finally {
					this.disconnect();
				}
				return loaninfos;
	}
	
	
	public LoanInfo getLoanStatus(String applno) throws SQLException{
		 LoanInfo loaninfo = new LoanInfo();
		try {
		this.connect();
		//Connection connection = ((Statement) dataSource).getConnection();
	  
		//System.out.println("Connect getLoanStatusQuery");
		ResultSet result1;
		PreparedStatement pstmt=jdbcConnection.prepareStatement("select status from LoanDetails where applno=?");
		
		pstmt.setString(1,applno);
		result1=pstmt.executeQuery();
		while(result1.next())
		{
			loaninfo.setApplno(applno);
			loaninfo.setStatus(result1.getString(1));
			System.out.println("Executed getLoanStatusQuery");
			//loaninfo.setApplno("applno");
		//result1.getString("status");
		//return result1;
		//loans.add(loanstatus);
		//System.out.println(status);
		}
		
		}catch (SQLException e) {
			System.out.println(e);
			e.printStackTrace();
		}
		return loaninfo ;
		}
	
	public LoanInfo getLoanDetails(String applno) throws Exception{
		 LoanInfo loaninfo = new LoanInfo();
		try {
		this.connect();
		//Connection connection = ((Statement) dataSource).getConnection();
	  
		//System.out.println("Connect getLoanStatusQuery");
		ResultSet result1;
		PreparedStatement pstmt=jdbcConnection.prepareStatement("select * from LoanDetails where applno=?");
		pstmt.setString(1,applno);
		result1=pstmt.executeQuery();
		while(result1.next())
		{
			loaninfo.setApplno(result1.getString(1));
			loaninfo.setPurpose(result1.getString(2));
			loaninfo.setAmtrequest(result1.getString(3));
			loaninfo.setDoa(result1.getString(4));
			loaninfo.setBstructure(result1.getString(5));
			loaninfo.setBindicator(result1.getString(6));
			loaninfo.setAddress(result1.getString(7));
			loaninfo.setEmail(result1.getString(8));
			loaninfo.setMobile(result1.getString(9));
			loaninfo.setStatus(result1.getString(10));
			//System.out.println("Executed getLoanStatusQuery");
			//loaninfo.setApplno("applno");
		//result1.getString("status");
		//return result1;
		//loans.add(loanstatus);
		//System.out.println(status);
		}
		
		
		}catch (SQLException e) {
			System.out.println(e);
			e.printStackTrace();
		}
		return loaninfo ;
		}
	
	public LoanInfo getLoanInfo(String applno) throws Exception{
		 LoanInfo loaninfo = new LoanInfo();
		try {
		this.connect();
		ResultSet result1;
		PreparedStatement pstmt=jdbcConnection.prepareStatement("select * from LoanDetails where applno=?");
		pstmt.setString(1,applno);
		result1=pstmt.executeQuery();
		while(result1.next())
		{
			loaninfo.setApplno(result1.getString(1));
			loaninfo.setPurpose(result1.getString(2));
			loaninfo.setAmtrequest(result1.getString(3));
			loaninfo.setDoa(result1.getString(4));
			loaninfo.setBstructure(result1.getString(5));
			loaninfo.setBindicator(result1.getString(6));
			loaninfo.setAddress(result1.getString(7));
			loaninfo.setEmail(result1.getString(8));
			loaninfo.setMobile(result1.getString(9));
			loaninfo.setStatus(result1.getString(10));
			System.out.println("I'm in getLoanInfo.");
			//loaninfo.setApplno("applno");
		//result1.getString("status");
		//return result1;
		//loans.add(loanstatus);
		//System.out.println(status);
		}
		}catch (SQLException e) {
			System.out.println(e);
			e.printStackTrace();
		}
		return loaninfo ;
		}
	
	public void updateLoanInfo(String applno, String status, String sanctionedAmount, String emi, String interestrate, String termofloan,int tpa) {
		try {
			this.connect();
			int result;
			PreparedStatement pstmt=jdbcConnection
					.prepareStatement("update LoanDetails set status=?, sancamt=?, emi=?, roi=?, tol=?,tpa=? where applno=?");
			pstmt.setString(1, status);
			pstmt.setString(2, sanctionedAmount);
			pstmt.setString(3, emi);
			pstmt.setString(4, interestrate);
			pstmt.setString(5, termofloan);
			pstmt.setInt(6, tpa);
			pstmt.setString(7, applno);
			result = pstmt.executeUpdate();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
}
