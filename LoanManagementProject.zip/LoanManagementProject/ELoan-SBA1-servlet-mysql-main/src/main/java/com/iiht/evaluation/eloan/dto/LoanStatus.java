package com.iiht.evaluation.eloan.dto;

public class LoanStatus {
	 private String status;
	 private String applno;
	 
	 
	public LoanStatus(String status, String applno) {
		super();
		this.status = status;
		this.applno = applno;
	}
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	public String getApplno() {
		return applno;
	}
	public void setApplno(String applno) {
		this.applno = applno;
	}
	 
}
