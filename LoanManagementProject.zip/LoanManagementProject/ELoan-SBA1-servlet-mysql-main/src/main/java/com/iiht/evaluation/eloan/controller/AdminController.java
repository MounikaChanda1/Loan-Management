package com.iiht.evaluation.eloan.controller;

import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletConfig;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.iiht.evaluation.eloan.dao.ConnectionDao;
import com.iiht.evaluation.eloan.dto.LoanDto;
import com.iiht.evaluation.eloan.model.ApprovedLoan;
import com.iiht.evaluation.eloan.model.LoanInfo;


@WebServlet("/admin")
public class AdminController extends HttpServlet {
	private static final long serialVersionUID = 1L;
	private ConnectionDao connDao;
	
	public void setConnDao(ConnectionDao connDao) {
		this.connDao = connDao;
	}
	public void init(ServletConfig config) {
		String JDBdriver = config.getServletContext().getInitParameter("jdbcDriver");
		String jdbcURL = config.getServletContext().getInitParameter("jdbcUrl");
		String jdbcUsername = config.getServletContext().getInitParameter("jdbcUsername");
		String jdbcPassword = config.getServletContext().getInitParameter("jdbcPassword");
		System.out.println(JDBdriver+jdbcURL + jdbcUsername + jdbcPassword);
		this.connDao = new ConnectionDao(JDBdriver,jdbcURL, jdbcUsername, jdbcPassword);
	}

	public void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		doGet(request, response);
	}

	public void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		String action =  request.getParameter("action");
		System.out.println(action);
		String viewName = "";
		try {
			switch (action) {
			case "listall" : 
				viewName = listall(request, response);
				break;
			case "process":
				viewName=process(request,response);
				break;
			case "callemi":
				viewName=calemi(request,response);
				break;
			case "updatestatus":
				viewName=updatestatus(request,response);
				break;
			case "logout":
				viewName = adminLogout(request, response);
				break;	
			default : viewName = "notfound.jsp"; break;		
			}
		} catch (Exception ex) {
			throw new ServletException(ex.getMessage());
		}
		RequestDispatcher dispatch = 
					request.getRequestDispatcher(viewName);
		dispatch.forward(request, response);
		
		
	}

	private String updatestatus(HttpServletRequest request, HttpServletResponse response) throws Exception {
		// TODO Auto-generated method stub
		/* write the code for updatestatus of loan and return to admin home page */
		String applno = request.getParameter("applno");
		String sanctionedAmount = request.getParameter("sanctionedamount");
		String interestrate = request.getParameter("interestrate");
		String termofloan = request.getParameter("termofloan");
		String status = request.getParameter("status");
		if (status.equals("Rejected")) {
			connDao.updateLoanInfo(applno, status, "0", "0", "0", "0",0);
			return "adminhome1.jsp";
		}
		if (sanctionedAmount != null && !sanctionedAmount.isEmpty() &&
				interestrate != null && !interestrate.isEmpty() &&
				termofloan != null && !termofloan.isEmpty()) {
			int x = Integer.valueOf(sanctionedAmount);
			int y = Integer.valueOf(interestrate);
			int z = Integer.valueOf(termofloan);
			int tpa = (int) (x * Math.pow(((100 + y) / 100.0 ), z));
			int emi= tpa/z;
			connDao.updateLoanInfo(applno, status, sanctionedAmount, String.valueOf(emi), interestrate, termofloan,tpa);
		}
		else {
			throw new Exception("Please fill all the values.");
		}
		return "adminhome1.jsp";
	}
	private String calemi(HttpServletRequest request, HttpServletResponse response) throws Exception {
		// TODO Auto-generated method stub
	/* write the code to calculate emi for given applno and display the details */
		String applno = request.getParameter("applno");
		LoanInfo loaninfo = connDao.getLoanInfo(applno);
		if (!loaninfo.getStatus().equals("Pending")) {
			request.setAttribute("errMsg", "You cannot edit processed loan applications.");
			return "errorPage.jsp";
		}
		request.setAttribute("loaninfo", loaninfo);
		return "calemi.jsp";
	}
	private String process(HttpServletRequest request, HttpServletResponse response) throws SQLException {
		// TODO Auto-generated method stub
	/* return to process page */
		return  "process.jsp";
	}
	private String adminLogout(HttpServletRequest request, HttpServletResponse response) {
		// TODO Auto-generated method stub
	/* write code to return index page */
		return null;
	}

	private String listall(HttpServletRequest request, HttpServletResponse response) throws SQLException {
	/* write the code to display all the loans */
		List<LoanInfo> loans = connDao.getLoansList();
		List<ApprovedLoan> apploans = connDao.getApprovedLoansList();
		request.setAttribute("loans", loans);
		request.setAttribute("apploans", apploans);
		return "listall.jsp";
	}

	
}